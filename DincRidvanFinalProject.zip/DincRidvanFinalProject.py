"""
Program: DincRidvanFinalProject.py
Author: Ridvan Dinc
Last date modified: 05/11/2023

This module defines the TicketFinder class.
"""
from breezypythongui import EasyFrame
from tkinter import *

class TicketFinder(EasyFrame):
    """This class lets the user see, sort, and buy tickets."""
    
    def __init__(self):
        """Sets up the window,widgets, and data."""
        EasyFrame.__init__(self,  title = "Ticket Finder")
        self.shoppingCart = [] #This list keeps all tickets added to cart
        self.sortNum = 1 #Tracks whether user entered sort button
        self.setResizable(False) 
        self.total = 0 #Stores total price of all tickets added to cart
        
        #Row 0
        self.citySearch = self.addTextField(text = "Enter city name to add tickets to cart", row = 0, column = 0,
                                            sticky = "NSEW") #Stores text field for adding tickets to cart
        self.searchButton = self.addButton(text = "Add to Cart", row = 0, column = 1, command = self.addToCartSearchBar) #Button that adds tickets to cart when city name is entered in text field  
        self.openCart = self.addButton(text = "View Cart", row = 0, column = 3, command = self.viewCart) #Button to view cart window
        self.sort = self.addButton(text = "Sort by Price", row = 0, column = 2, command = self.sortByPrice) #Button to sort tickets by price
        self.exit = self.addButton(text = "Exit", row = 0, column = 4, command = exit) #Button to exit program
        
        #Row 1
        self.parisImage = self.addLabel(text = "Eiffel Tower",
                                       row = 1, column = 0,
                                       sticky = "NSEW") #Stores image of Eiffel Tower for Paris ticket
        self.parisLabel = self.addLabel(text = "Indianapolis - Paris",
                                       row = 1, column = 1,
                                       sticky = "NSEW",
                                       columnspan = 1) #Stores departure and destination location of ticket
        self.priceParis = self.addLabel(text = "$1600.00",
                                       row = 1, column = 2,
                                       sticky = "NSEW",) #Stores price of ticket
        self.addParis = self.addButton(text = "Add to Cart", row = 1,
                                    column = 3, command = self.addToCartParis) #Button for adding ticket to cart, adds Paris ticket to cart
        
        #Row 2
        self.londonImage = self.addLabel(text = "London Bridge",
                                       row = 2, column = 0,
                                       sticky = "NSEW",) #Stores image of London Bridge for London ticket
        self.londonLabel = self.addLabel(text = "Indianapolis - London",
                                       row = 2, column = 1,
                                       sticky = "NSEW",
                                       columnspan = 1) #Stores departure and destination location of ticket
        self.priceLondon = self.addLabel(text = "$1500.00",
                                       row = 2, column = 2,
                                       sticky = "NSEW") #Stores price of ticket
        self.addLondon = self.addButton(text = "Add to Cart", row = 2,
                                    column = 3, command = self.addToCartLondon) #Button for adding ticket to cart, adds London ticket to cart
        
        #Row 3
        self.romaImage = self.addLabel(text = "The Colosseum",
                                       row = 3, column = 0,
                                       sticky = "NSEW") #Stores image of the Colosseum for Roma ticket
        self.romaLabel = self.addLabel(text = "Indianapolis - Roma",
                                       row = 3, column = 1,
                                       sticky = "NSEW",
                                       columnspan = 1) #Stores departure and destination location of ticket
        self.priceRoma = self.addLabel(text = "$1700.00",
                                       row = 3, column = 2,
                                       sticky = "NSEW") #Stores price of ticket
        self.addRoma = self.addButton(text = "Add to Cart", row = 3,
                                    column = 3, command = self.addToCartRoma) #Button for adding ticket to cart, adds Roma ticket to cart

    
        self.parisImageFile = PhotoImage(file = "paris.gif") #Stores image of Paris ticket 
        self.londonImageFile = PhotoImage(file = "london.gif") #Stores image of London ticket 
        self.romaImageFile = PhotoImage(file = "roma.gif") #Stores image of Roma ticket 
        
        '''Loading images to labels'''
        self.parisImage["image"] = self.parisImageFile 
        self.londonImage["image"] = self.londonImageFile
        self.romaImage["image"] = self.romaImageFile
    
    def addToCartParis(self):
        '''Adds paris ticket to shoppingCart list and paris cost to total'''
        self.shoppingCart.append("Indianapolis - Paris $1600")
        self.total += 1600.00

    def addToCartLondon(self):
        '''Adds london ticket to shoppingCart list and london cost to total'''
        self.shoppingCart.append("Indianapolis - London $1500")
        self.total += 1500.00

    def addToCartRoma(self):  
        '''Adds roma ticket to shoppingCart list and roma cost to total'''
        self.shoppingCart.append("Indianapolis - Roma $1700")
        self.total += 1700.00
    
    def sortByPrice(self):
        '''Sorts tickets in main window. If sortNum is 1, it sorts by lowest to highest price
        and if 0, highest to lowest.'''
        if self.sortNum:
            self.londonImage.grid(row = 1)
            self.londonLabel.grid(row = 1)
            self.priceLondon.grid(row = 1)
            self.addLondon.grid(row = 1)
            self.parisImage.grid(row = 2)
            self.parisLabel.grid(row = 2)
            self.priceParis.grid(row = 2)
            self.addParis.grid(row = 2)
            self.romaImage.grid(row = 3)
            self.romaLabel.grid(row = 3)
            self.priceRoma.grid(row = 3)
            self.addRoma.grid(row = 3)
            self.sortNum = 0
        else:
            self.romaImage.grid(row = 1)
            self.romaLabel.grid(row = 1)
            self.priceRoma.grid(row = 1)
            self.addRoma.grid(row = 1)
            self.parisImage.grid(row = 2)
            self.parisLabel.grid(row = 2)
            self.priceParis.grid(row = 2)
            self.addParis.grid(row = 2)            
            self.londonImage.grid(row = 3)
            self.londonLabel.grid(row = 3)
            self.priceLondon.grid(row = 3)
            self.addLondon.grid(row = 3)
            self.sortNum = 1
            
    def addToCartSearchBar(self):
        '''Adds tickets to cart that have been entered from seach bar'''
        city = self.citySearch.getText() #Stores input entered in search bar
        
        '''Adds tickets to shoppingCart list and price of tickets to total. User
        must enter city name to do this. If user enter anything else from cities available, 
        an error message is displayed.'''
        if city.lower() == "roma":
            self.shoppingCart.append("Indianapolis - Roma $1700")
            self.total += 1700.00
        elif city.lower() == "london":
            self.shoppingCart.append("Indianapolis - London $1500")
            self.total += 1500.00
        elif city.lower() == "paris":
            self.shoppingCart.append("Indianapolis - Paris $1600")
            self.total += 1600.00
        else:
            self.messageBox(title="Error", message="Enter a valid city name")
            
    def viewCart(self):
        '''Instantiates cartWindow and displays tickets bought and total cost in this window.'''
        cartWindow = Toplevel()
        total = "Total: $" + str(self.total)
        
        '''Displays tickets in shoppingCart list and total cost.
        Displays empty message if shoppingCart list has no values.'''
        if len(self.shoppingCart) == 0:
            Label(cartWindow, text="Your shopping cart is empty.").grid(row = 0, column= 0)
        else:
            Label(cartWindow, text="Your shopping cart contains the following tickets:").grid(row = 0, column= 0, sticky=W)
            for num in range(len(self.shoppingCart)):
                Label(cartWindow,text=self.shoppingCart[num]).grid(row = num + 1, column= 0, sticky=W)
            Label(cartWindow,text = total).grid(row = len(self.shoppingCart)+1, column= 0, sticky=W)

        '''Closes cart window'''    
        Button(cartWindow, text="Close Cart", command=cartWindow.destroy).grid(row = len(self.shoppingCart)+2, column= 0)
        
def main():
    """Instantiate and pop up the window."""
    TicketFinder().mainloop()

if __name__ == "__main__":
    main()
