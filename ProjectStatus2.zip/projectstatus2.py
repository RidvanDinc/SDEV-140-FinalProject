from breezypythongui import EasyFrame
from tkinter import *

class TicketFinder(EasyFrame):
    def __init__(self):
        """Sets up the window,widgets, and data."""
        EasyFrame.__init__(self,  title = "Ticket Finder")
        self.romaTickets = 0
        self.londonTickets = 0
        self.parisTickets = 0
        self.sortNum = 1
        #Row 1
        self.citySearch = self.addTextField(text = "Enter city name to add tickets to cart", row = 0, column = 0,
                                            sticky = "NSEW")
        self.searchButton = self.addButton(text = "Add to Cart", row = 0, column = 1, command = self.addToCartSearchBar)  
        openCart = self.addButton(text = "Cart", row = 0, column = 3, command = self.cart)
        sort = self.addButton(text = "Sort by Price", row = 0, column = 2, command = self.sortByPrice)
        #Row 2
        self.parisImage = self.addLabel(text = "",
                                       row = 1, column = 0,
                                       sticky = "NSEW")
        self.parisLabel = self.addLabel(text = "Indianapolis - Paris",
                                       row = 1, column = 1,
                                       sticky = "NSEW",
                                       columnspan = 1)
        self.priceParis = self.addLabel(text = "$1600.00",
                                       row = 1, column = 2,
                                       sticky = "NSEW",)
        self.addParis = self.addButton(text = "Add to Cart", row = 1,
                                    column = 3, command = self.addToCartParis)
        #Row 3
        self.londonImage = self.addLabel(text = "",
                                       row = 2, column = 0,
                                       sticky = "NSEW",)
        self.londonLabel = self.addLabel(text = "Indianapolis - London",
                                       row = 2, column = 1,
                                       sticky = "NSEW",
                                       columnspan = 1)
        self.priceLondon = self.addLabel(text = "$1500.00",
                                       row = 2, column = 2,
                                       sticky = "NSEW")
        self.addLondon = self.addButton(text = "Add to Cart", row = 2,
                                    column = 3, command = self.addToCartLondon)
        #Row 4
        self.romaImage = self.addLabel(text = "",
                                       row = 3, column = 0,
                                       sticky = "NSEW")
        self.romaLabel = self.addLabel(text = "Indianapolis - Roma",
                                       row = 3, column = 1,
                                       sticky = "NSEW",
                                       columnspan = 1)
        self.priceRoma = self.addLabel(text = "$1700.00",
                                       row = 3, column = 2,
                                       sticky = "NSEW")
        self.addRoma = self.addButton(text = "Add to Cart", row = 3,
                                    column = 3, command = self.addToCartRoma)

    
        self.parisImageFile = PhotoImage(file = "paris.gif")
        self.londonImageFile = PhotoImage(file = "london.gif")
        self.romaImageFile = PhotoImage(file = "roma.gif")
        
        self.parisImage["image"] = self.parisImageFile
        
        self.londonImage["image"] = self.londonImageFile
        
        self.romaImage["image"] = self.romaImageFile
    
    def addToCartParis(self):
        self.parisTickets += 1

    def addToCartLondon(self):
        self.londonTickets += 1

    def addToCartRoma(self):  
        self.romaTickets += 1

    def cart(self):
        print(self.londonTickets, self.romaTickets, self.parisTickets)
    
    def sortByPrice(self):
        if self.sortNum:
            self.londonImage.grid(row = 1)
            self.londonLabel.grid(row = 1)
            self.priceLondon.grid(row = 1)
            self.addLondon.grid(row = 1)
            self.parisImage.grid(row = 2)
            self.parisLabel.grid(row = 2)
            self.priceParis.grid(row = 2)
            self.addParis.grid(row = 2)
            self.romaImage.grid(row = 3)
            self.romaLabel.grid(row = 3)
            self.priceRoma.grid(row = 3)
            self.addRoma.grid(row = 3)
            self.sortNum = 0
        else:
            self.romaImage.grid(row = 1)
            self.romaLabel.grid(row = 1)
            self.priceRoma.grid(row = 1)
            self.addRoma.grid(row = 1)
            self.parisImage.grid(row = 2)
            self.parisLabel.grid(row = 2)
            self.priceParis.grid(row = 2)
            self.addParis.grid(row = 2)            
            self.londonImage.grid(row = 3)
            self.londonLabel.grid(row = 3)
            self.priceLondon.grid(row = 3)
            self.addLondon.grid(row = 3)
            self.sortNum = 1
            
    def addToCartSearchBar(self):
        city = self.citySearch.getText()
        if city.lower() == "roma":
            self.romaTickets += 1
        elif city.lower() == "london":
            self.londonTickets += 1
        elif city.lower() == "paris":
            self.parisTickets += 1
        else:
            self.messageBox(title="Error", message="Enter a valid city name")
    
    def cart(self):
        messageColumnHeadings = "Flight                      Quantity         Price\n"
        romaMessage = ""
        londonMessage = ""
        parisMessage = ""
        
        romaTicketTotal = self.romaTickets * 1700
        londonTicketTotal = self.londonTickets * 1500
        parisTicketTotal = self.parisTickets * 1600
        
        if romaTicketTotal > 0:
            romaMessage = "Indianapolis - Roma:           " + str(self.romaTickets) + "             $1700" + "\n"
        if londonTicketTotal > 0:
            londonMessage = "Indianapolis - London:         " + str(self.londonTickets) + "             $1500" + "\n"
        if parisTicketTotal > 0:
            parisMessage = "Indianapolis - Paris:          " + str(self.parisTickets) + "             $1600" + "\n"
        
        totalPrice = romaTicketTotal + londonTicketTotal + parisTicketTotal
        message = messageColumnHeadings + romaMessage + londonMessage + parisMessage + "Total: $" + str(totalPrice)

        self.messageBox(title = "Cart", message = message, width=100, height=50)
        

            
def main():
    """Instantiate and pop up the window."""
    TicketFinder().mainloop()
    

if __name__ == "__main__":
    main()
